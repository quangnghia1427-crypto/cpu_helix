# HELIX-1 Branch V5 — benchmark interpretation

The main qualification run uses 1,000 seeded random programs, half with a backward loop. Functional correctness is checked by comparing architectural registers, DMEM, and fault status against `golden()` with branch prediction both on and off.

The report has four distinct branch metrics:

- **Predictor-only accuracy**: correct guesses divided by the number of branches for which the predictor actually speculated. Exact early-resolved branches and deferred branches are excluded.
- **Combined direction-decision accuracy**: correct predictor guesses plus exact early resolutions divided by guessed plus early-resolved branches. Deferred branches are excluded.
- **No-redirect rate**: one minus actual wrong-path redirects divided by all retired conditional branches. This includes deferred branches and is not prediction accuracy.
- **IPC**: total retired instructions divided by total simulated cycles over the sample.

Observed sample results are recorded in `test_results_default.txt` and `test_results_max_ipc.txt`. Do not substitute the separate hand-written ILP performance benchmarks for the random stress result.
