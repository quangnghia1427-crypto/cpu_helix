# HELIX-1 Branch V5

HELIX-1 Branch V5 is a C++17 cycle-level reference simulator derived from the uploaded V4 source. It is not synthesizable RTL and does not provide FPGA timing/resource evidence.

## What changed

1. Keeps the V4 hybrid predictor: Bimodal + Gshare + Local + four tagged TAGE history tables (4/8/16/32 bits), BTB, and RAS.
2. Adds a 0..3 predictor confidence estimate based on the selected counter strength and the TAGE provider.
3. Default mode (`--bp-confidence 1`) defers a low-confidence conditional branch: Fetch stops at that branch, the speculative GHR/local-history changes are rolled back, and Fetch resumes from the exact target when the branch executes. This avoids sending a large wrong-path window through the machine.
4. Maintains exact early BEQ resolution when both operands are ready at Fetch.
5. Exposes `--bp-confidence 0` for maximum speculation / higher IPC, and `--bp-confidence 1` for confidence-gated mode.
6. Reports predictor-only accuracy separately from early exact resolutions, deferred branches, and the no-redirect rate.

## Stress results (seed 2026, 1,000 random programs, 500 loop programs)

All 1,000 programs matched `golden()` in both BP-on and BP-off modes; 353 programs ended in a fault.

| Metric | Confidence 0 (maximum speculation) | Confidence 1 (default) |
|---|---:|---:|
| Stress IPC, BP on | **3.525** | 3.137 |
| Predictor-only accuracy (branches it actually speculated on) | 75.8% | 82.8% |
| Branches with an explicit predictor guess | 4,289 / 6,056 (70.8%) | 2,599 / 6,056 (42.9%) |
| Early exact BEQ resolutions | 1,767 | 1,973 |
| Deferred low-confidence branches | 0 | 1,484 |
| Redirects | 823 / 6,056 | 418 / 6,056 |
| No-redirect rate | 86.4% | **93.1%** |

For confidence 1, the combined direction-decision accuracy across *guessed branches plus exact early-resolved branches* is:

`(2,599 - 446 + 1,973) / (2,599 + 1,973) = 90.2%`.

This is not raw predictor-only accuracy. Predictor-only accuracy is 82.8%; 24.5% of branches are deferred rather than guessed. The 93.1% figure is the no-redirect rate, not prediction accuracy. The default trades IPC (3.137) for fewer wrong-path redirects. Use confidence 0 when the priority is the highest stress IPC (3.525).

## Build and run

```bash
chmod +x run_linux.sh
./run_linux.sh                 # default confidence 1
./run_linux.sh --bp-confidence 0  # maximum speculation / IPC mode
```

The source is configured to run the 1,000-program stress test with seed 2026, followed by directed tests and separate performance benchmarks.

## Important limits

- The confidence-gated mode deliberately stalls Fetch on low-confidence branches; it does not magically make the predictor itself >90% accurate.
- Stress IPC is aggregated `retired / cycles` over this particular fixed 1,000-program sample, not a guarantee for every program.
- `--penalty 0` remains an optimistic same-cycle redirect assumption in this software model.
- Predictor tables, ROB, BTB, and RAS are C++ data structures. This program cannot be loaded onto the KIWI PRIMER 20K FPGA. A separate SystemVerilog implementation, BRAM mapping, timing closure, and RTL verification would be required.
