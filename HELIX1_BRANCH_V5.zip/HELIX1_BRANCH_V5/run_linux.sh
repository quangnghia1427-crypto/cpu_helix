#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -o helix1_v5 HELIX1_BRANCH_V5.cpp
./helix1_v5 "$@"
