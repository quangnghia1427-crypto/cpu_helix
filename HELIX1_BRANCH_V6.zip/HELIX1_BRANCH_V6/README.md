# HELIX-1 Branch V6

HELIX-1 Branch V6 is a C++17 cycle-level reference simulator for a 6-wide out-of-order CPU. It is **not synthesizable RTL** and its IPC values are simulator measurements, not FPGA or silicon timing results.

## Branch-prediction changes

- Six tagged TAGE tables with global-history lengths **4, 8, 16, 32, 64 and 128 bits**.
- A 128-bit GHR represented as two 64-bit words, keeping the code portable C++17 (no compiler-specific `__int128`).
- A separate 128-bit path-history register. Each branch contributes an 8-bit token: seven hashed PC bits plus the predicted/actual direction bit. This keeps the last 16 branch tokens.
- Folded-XOR history hashing for TAGE indexes and tags. The path signature participates in both index and tag formation.
- A usefulness-based TAGE provider/alternate choice and a smart allocator. A static branch must miss twice consecutively before allocating a longer-history entry; allocation is limited to one tagged table per miss.
- GHR, path-history, local-history and RAS checkpoints. Recovery now also notices a direction miss when a BEQ's taken and not-taken outcomes happen to have the same next PC (for example, immediate +1); younger speculative entries are flushed and predictor history is repaired.
- Confidence gating remains configurable, but the V6 default is `--bp-confidence 0`, so the frontend does not deliberately stall on low-confidence conditional branches.

## Build and run

Linux with g++ supporting C++17:

```bash
./run_linux.sh
```

Equivalent explicit build:

```bash
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -o helix1_v6 HELIX1_BRANCH_V6.cpp
./helix1_v6 --bp-confidence 0
```

Useful options:

```bash
./helix1_v6 --bp-confidence 0 --hist-bits 128 --entries 512
./helix1_v6 --bp-confidence 1
./helix1_v6 --bp-confidence 0 --entries 1024
./helix1_v6 --bp-confidence 0 --penalty 1
```

`--bp-confidence 0` prioritizes prediction coverage/IPC. `--bp-confidence 1` enables the conservative confidence gate and may reduce IPC. `--hist-bits` accepts 4..128. `--entries` accepts powers of two from 16 through 4096.

## Tests

- 24 directed tests pass, including a direction-mispredict/same-next-PC recovery regression.
- 1,000 random programs (500 loop programs) match the golden interpreter with BP on and off.
- AddressSanitizer + UndefinedBehaviorSanitizer run completes without a report.
- The benchmark suite checks 4/5/6 independent ALU chains, 1,000 independent loads, a long loop kernel, and an even/odd branch kernel.

See `BENCHMARKS.md` for actual measurements and caveats.

## Important limitations

- The random stress suite creates a fresh predictor for each short program. Many branches execute only once or a few times, so a long-history predictor has little opportunity to learn. Do not interpret this as representative of long-running applications.
- Accuracy is split into **predictor-only accuracy** (only branches on which the predictor actually made a direction prediction), coverage, early exact resolutions, and redirect rate. These are different metrics.
- The 128-bit path register is a compact hashed path signature, not a lossless record of complete instruction addresses.
- The cache, memory, pipeline widths and branch recovery are abstractions in a functional/cycle simulator; this is not a power model and cannot substantiate a 130 W laptop energy claim.
- This C++ program cannot be loaded onto the Tang/KIWI Primer FPGA. A separate SystemVerilog design, timing closure and board-level validation would be required.
