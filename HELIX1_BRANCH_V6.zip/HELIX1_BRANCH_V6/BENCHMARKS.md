# HELIX-1 Branch V6 — benchmark report

All measurements below were produced by the bundled V6 C++17 simulator in this run. Stress seed: **2026**. The stress test uses **1,000 independently initialized programs**, 500 of which contain loops. Results are not a guarantee for other programs.

## Main no-stall configuration

Configuration: 6-wide issue, ROB128, 8-bank LSU, 512 entries/table, six TAGE histories (4/8/16/32/64/128), 128-bit GHR, 128-bit path history, `--bp-confidence 0`, redirect penalty 0.

| Metric | Measured result |
|---|---:|
| Correctness vs golden, BP on/off | 1,000 / 1,000 programs |
| Programs that fault | 353 |
| IPC, BP off | 1.922 |
| IPC, BP on | **3.435** |
| Conditional branches retired | 6,056 |
| Predictor decisions actually made | 4,192 |
| Predictor misses | 1,106 |
| Predictor-only accuracy | **73.6%** (3,086 / 4,192) |
| Predictor coverage | 69.2% |
| Exact early resolutions | 1,864 |
| Conditional branches requiring redirect | 1,106 |
| Branches with no redirect | 81.7% |
| Wrong-path instructions flushed | 37,816 |

Predictor-only accuracy excludes branches solved exactly at Fetch and excludes any branch on which the confidence gate deferred prediction. In the main V6 run, the confidence gate was disabled; 1,864 branches were solved early from ready operands and 4,192 branches were actually predicted.

## Predictable branch kernels

These two long-running kernels have 100% predictor coverage and no early exact branch resolution, so the figures below are true predictor-only measurements for those kernels.

| Kernel | Predictor-only accuracy | Coverage | IPC with BP |
|---|---:|---:|---:|
| Loop kernel, 2,000 iterations | **99.95%** (1,999 / 2,000) | 100.0% | 5.988 |
| Even/odd branch kernel, 4,000 iterations | **91.61%** (7,329 / 8,000) | 100.0% | 5.245 |

Combined performance suite (six performance cases): **5.311 IPC**. This suite is ILP-rich and is reported separately from the random correctness stress test.

## Confidence-gated comparison

With `--bp-confidence 1`:

| Metric | Result |
|---|---:|
| Random stress IPC | 3.098 |
| Predictor-only accuracy | 82.5% (2,039 / 2,472) |
| Predictor coverage | 40.8% |
| Deferred / waited branches | 1,573 |
| Branches not requiring redirect | 92.9% |

The higher no-redirect rate comes with lower prediction coverage and lower IPC. It must not be presented as a predictor-only accuracy improvement to 92.9%.

## Comparison to V5 reference

V5 was also measured with the same direction-miss/same-next-PC recovery correction applied, to keep recovery semantics comparable:

| Version | Random stress IPC | Predictor-only accuracy |
|---|---:|---:|
| V5 corrected reference, 4 TAGE tables / 32-bit GHR | 3.480 | 77.3% |
| V6, 6 TAGE tables / 128-bit GHR + path history | 3.435 | 73.6% |

The V6 long-history/path design **does not improve the short cold-start random stress test**. Increasing table entries from 512 to 1,024 or 2,048 produced no material change in this stress test. The V6 advantage is demonstrated on repeatable long-running branch kernels (91.61% and 99.95% predictor-only), not on every workload.

## Validation

- Build: `g++ -std=c++17 -O2 -Wall -Wextra -pedantic` — pass without warnings.
- Directed tests: 24 pass.
- Random golden comparison: 1,000 / 1,000 pass, BP on and off.
- AddressSanitizer + UndefinedBehaviorSanitizer: pass, no report.
- New regression: a BEQ direction prediction can be wrong even when its predicted next PC equals the actual next PC. V6 now repairs GHR/path state and flushes younger speculative entries in that case.

## Interpretation limits

The random suite resets predictor state for every small program and contains a substantial number of single-use or short-lived branches. Long TAGE histories need repeated dynamic observations to learn. The V6 random-stress predictor-only result is 73.6%, **not above 90%**. Above-90% predictor-only accuracy was measured on the included long-running deterministic branch kernels only. No hardware power, energy, frequency, FPGA fit or RTL timing result is claimed.

## One-cycle redirect sensitivity

With `--bp-confidence 0 --penalty 1`:

| Metric | Measured result |
|---|---:|
| Random stress IPC | 3.152 |
| Random stress predictor-only accuracy | 75.7% (3,174 / 4,195) |
| Random stress predictor coverage | 69.3% |
| Loop kernel predictor-only accuracy | 99.95% (1,999 / 2,000) |
| Even/odd kernel predictor-only accuracy | 99.90% (7,992 / 8,000) |
| Combined performance suite IPC | 5.069 |

These are simulator results with an additional redirect bubble, not measured clock-cycle timing on hardware.
