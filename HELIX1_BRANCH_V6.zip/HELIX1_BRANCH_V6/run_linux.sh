#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -o helix1_v6 HELIX1_BRANCH_V6.cpp
./helix1_v6 "$@"
