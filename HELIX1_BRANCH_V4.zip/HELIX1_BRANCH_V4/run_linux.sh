#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -o helix1_v4 HELIX1_BRANCH_V4.cpp
exec ./helix1_v4 "$@"
