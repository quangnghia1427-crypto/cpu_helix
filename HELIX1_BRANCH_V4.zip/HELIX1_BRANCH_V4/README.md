# HELIX-1 Branch V4

Bản nâng cấp từ file `HELIX1_6wide_OOO_ROB128_PRED512.cpp` mà người dùng cung cấp. Đây là **mô hình tham chiếu C++17 theo chu kỳ**, không phải RTL tổng hợp được và không phải bằng chứng timing/IPC trên FPGA.

## Các thay đổi chính

1. **Hybrid TAGE predictor**: giữ Bimodal, Gshare và Local làm predictor nền; bổ sung bốn bảng tagged dùng lịch sử toàn cục dài 4/8/16/32 bit. Mỗi bảng có 512 entry, tag, bộ đếm hướng có dấu và usefulness. Predictor chọn entry khớp có lịch sử dài nhất; khi dự đoán sai sẽ thử cấp phát vào bảng lịch sử dài hơn.
2. **Local-history checkpoint/rollback**: Local History cập nhật theo đường suy đoán. Khi có redirect, các lần cập nhật của nhánh trẻ hơn được hoàn tác theo thứ tự ngược trước khi xóa phần đuôi ROB. Điều này tránh để nhánh trên đường sai làm nhiễu lịch sử của đường đúng.
3. **GHR và RAS recovery**: lưu GHR checkpoint cho từng lệnh; khi nhánh/JALR sai, phục hồi GHR và RAS về checkpoint phù hợp, sau đó áp dụng hướng nhánh thực tế. Khi fault làm dừng đường suy đoán cũng khôi phục trạng thái speculative trẻ hơn.
4. **Early branch resolution**: nếu toán hạng BEQ đã sẵn sàng ngay khi Fetch, so sánh chính xác tại Fetch, đánh dấu nhánh hoàn tất và không chiếm một slot Issue chu kỳ kế tiếp. `BEQ xN, xN` được giải quyết ngay vì hai toán hạng chắc chắn bằng nhau.
5. **Redirect có thể cấu hình**: `--penalty 0` mô phỏng frontend Fetch chạy lại ở cuối cùng chu kỳ mà nhánh được giải quyết. `--penalty 1` thêm một chu kỳ redirect để kiểm tra giả định thận trọng hơn.

## Cấu hình mặc định

- 6-wide issue, Fetch 12/cycle, Retire 8/cycle
- ROB 128
- Bimodal/Gshare/Local + 4 bảng TAGE, 512 entry mỗi bảng
- GHR 32 bit; BTB 512 entry; RAS 16 entry
- 8 bank LSU
- Redirect penalty mặc định: 0 chu kỳ trong mô hình

## Kết quả đã chạy

Bộ stress cố định: 5.000 chương trình ngẫu nhiên (2.500 chương trình có vòng lặp), seed 2026; mỗi chương trình được đối chiếu với `golden()` ở cả BP bật và BP tắt. Có 1.779 chương trình kết thúc bằng fault. Tất cả kết quả thanh ghi, DMEM và trạng thái fault đều khớp.

| Thiết lập | Bản gốc | Branch V4 |
|---|---:|---:|
| BP bật, penalty 0 | 3.416 IPC | **3.534 IPC** |
| BP bật, penalty 1 | 3.176 IPC | **3.308 IPC** |
| BP tắt, penalty 0 | 1.949 IPC | 1.949 IPC |
| BP tắt, penalty 1 | 1.259 IPC | 1.259 IPC |

So sánh penalty 0 với penalty 0 và penalty 1 với penalty 1 là phép so sánh cùng giả định. IPC stress là tổng `committed / cycles` cộng dồn qua 5.000 chương trình, không phải IPC cho mọi chương trình riêng lẻ.

Với cấu hình mặc định penalty 0, kết quả branch/recovery:

- 30.422 nhánh BEQ retire.
- Raw predictor direction sai 11.139 lần (độ chính xác hướng thô 63,4%).
- 9.288 nhánh được giải quyết chính xác sớm ở Fetch.
- 3.958 nhánh thực sự phải redirect/flush (13,0% tổng số nhánh).
- 170.330 lệnh đường sai bị flush.

Điều quan trọng: độ chính xác 63,4% là độ chính xác hướng thô của predictor trên tập stress có nhiều nhánh khó dự đoán; tỷ lệ redirect thực tế thấp hơn nhờ early resolution. Không nên gọi 87,0% “độ chính xác TAGE”; đó là tỷ lệ nhánh không cần redirect sau khi tính cả early resolution.

Bộ benchmark ILP thủ công riêng đạt 5.312 IPC ở penalty 0. Không dùng kết quả này thay cho stress IPC.

## Biên dịch và chạy trên Linux

```bash
chmod +x run_linux.sh
./run_linux.sh
```

Hoặc biên dịch thủ công:

```bash
g++ -std=c++17 -O2 -Wall -Wextra -pedantic -o helix1_v4 HELIX1_BRANCH_V4.cpp
./helix1_v4
```

Kiểm thử với thêm một chu kỳ redirect:

```bash
./helix1_v4 --penalty 1
```

Có thể chỉnh số entry và độ dài GHR:

```bash
./helix1_v4 --entries 512 --hist-bits 32 --penalty 1
```

## Kiểm thử

- 24 directed tests: PASS.
- 5.000 randomized programs: PASS, đối chiếu `golden()` 100% ở BP bật/tắt.
- AddressSanitizer + UndefinedBehaviorSanitizer: PASS, không có báo lỗi.
- `test_results_final.txt`: cấu hình mặc định penalty 0.
- `test_results_penalty1.txt`: cấu hình thêm một chu kỳ redirect.
- `sanitizer_results.txt`: log kiểm thử sanitizer.

## Giới hạn cần nhớ

- `--penalty 0` là giả định thuận lợi của thứ tự mô phỏng hiện tại (Execute rồi Fetch trong cùng `step()`), không chứng minh phần cứng thực có thể redirect trong 0 chu kỳ.
- TAGE trong chương trình này là mô hình C++ để nghiên cứu thuật toán; chưa mô hình timing cổng, SRAM macro, độ trễ đọc bảng hay xung đột port của predictor.
- ROB, BTB, bảng TAGE và RAS đang là cấu trúc dữ liệu phần mềm. Muốn nạp lên KIWI PRIMER 20K cần thiết kế lại RTL/SystemVerilog, ánh xạ RAM/BRAM và xác minh timing/resource riêng.
- Không có L1/L2/L3 đầy đủ, MMU/PCIe/DDR controller hoặc khả năng chạy Linux/AAA game trong bản này.
