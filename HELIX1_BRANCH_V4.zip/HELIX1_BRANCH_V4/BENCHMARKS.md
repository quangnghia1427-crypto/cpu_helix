# HELIX-1 Branch V4 - benchmark notes

## So sánh stress test (5.000 chương trình, seed 2026)

| Chỉ số | Original, penalty 0 | V4, penalty 0 | Original, penalty 1 | V4, penalty 1 |
|---|---:|---:|---:|---:|
| IPC BP bật | 3.416 | **3.534** | 3.176 | **3.308** |
| IPC BP tắt | 1.949 | 1.949 | 1.259 | 1.259 |
| BEQ sai/redirect | 4.829 | **3.958** | 4.441 | **3.782** |
| Tỷ lệ không redirect | 84.1% | **87.0%** | 85.4% | **87.6%** |
| Lệnh flush | 188.854 | **170.330** | 182.995 | **167.541** |

Original được biên dịch trực tiếp từ file người dùng tải lên. V4 được biên dịch với cùng `g++ -std=c++17 -O2 -Wall -Wextra -pedantic` và cùng seed/bộ chương trình.

## Cấu hình V4 mặc định

- 6-wide Issue; 12-wide Fetch; 8-wide Retire
- ROB 128
- GHR 32-bit
- 512-entry Bimodal, Gshare, Local PHT và mỗi bảng TAGE; TAGE history lengths: 4/8/16/32
- 512-entry BTB; RAS 16
- Redirect penalty 0

## Kết quả default

- 24 directed tests passed.
- 5.000 random tests passed; 1.779 program fault, all outputs match `golden()` for BP on and off.
- BP-on IPC 3.534; BP-off IPC 1.949.
- Raw direction prediction error 11.139 / 30.422; early-resolved branches 9.288; actual redirects 3.958; wrong-path flushed instructions 170.330.
- Six-case hand-designed mix IPC: 5.312 (reported separately from random stress).

## Kết quả penalty 1

- 5.000 random tests passed; all outputs match `golden()` for BP on and off.
- BP-on IPC 3.308; BP-off IPC 1.259.
- Raw direction prediction error 10.992 / 30.422; early-resolved branches 9.285; actual redirects 3.782; flushed instructions 167.541.
- Six-case hand-designed mix IPC: 5.068.

## Sanitizers

Built with:

```bash
g++ -std=c++17 -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -Wall -Wextra -pedantic
```

Ran the full default test suite with `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1` and `UBSAN_OPTIONS=halt_on_error=1`. Exit code 0; no sanitizer errors.
