# HELIX-1 Branch V7 — Benchmark Report

## Tóm tắt

- 4 integer ALU, tổng dispatch 6-wide.
- Predictor mặc định không dùng Confidence Gating.
- Stress IPC V7: **3.409**.
- Stress IPC V6 đối chứng với cùng `retire_width=10`: **3.446**.
- Chênh lệch stress: **-0.037 IPC (-1.07%)**.
- MIX IPC 6 benchmark: V7 **5.285**, V6 **5.311** (**-0.49%**).
- 25 directed tests PASS; 1.000 chương trình random khớp golden 100%; ASan/UBSan PASS.

Vì vậy, IPC tổng stress và MIX được giữ rất gần V6, nhưng không hoàn toàn bằng nhau. Thông lượng workload chỉ gồm ALU giảm như hệ quả trực tiếp của giới hạn bốn cổng.

## So sánh V6/V7 có kiểm soát

Để tránh chênh lệch retire-width, V6 đối chứng được build từ source V6 gốc và chỉ đổi `retire_width` từ 8 lên 10 — bằng giá trị mặc định của V7. Seed random là 2026, số mẫu là 1.000, bộ kiểm thử và môi trường chạy giữ nguyên.

| Đo lường | V6 (6 ALU) | V7 (4 ALU) | Chênh lệch |
|---|---:|---:|---:|
| Stress IPC, BP ON | 3.446 | **3.409** | -1.07% |
| Stress IPC, BP OFF | 1.923 | 1.901 | -1.14% |
| MIX IPC (6 benchmark) | 5.311 | **5.285** | -0.49% |
| 4 independent ALU chains | 3.994 | 3.994 | ~0% |
| 5 independent ALU chains | 4.993 | 3.995 | -20.0% |
| 6 independent ALU chains | 5.986 | 3.996 | -33.3% |
| 1.000 LW / 8 banks | 5.879 | 5.879 | ~0% |
| Loop control kernel, 2.000 iterations | 5.988 | 5.589 | -6.7% |
| Branch parity kernel, 8.000 conditional branches | 5.245 | **5.991** | +14.2% |

**Giải thích:** stress program có sự pha trộn ALU, nhánh và memory nên tổng IPC chỉ giảm khoảng 1%. Ngược lại, bài 5/6 ALU chains gần như chỉ dùng integer ALU; với bốn ALU, trần thông lượng của chúng xấp xỉ 4 lệnh/chu kỳ. Không thể giữ throughput 5.986 IPC của bài 6 ALU chains mà vẫn giới hạn đúng bốn ALU đơn-issue.

## Stress test 1.000 chương trình

- 1.000 chương trình; 500 chương trình có vòng lặp; seed 2026.
- 353 chương trình fault.
- Tất cả kết quả register/DMEM/fault khớp golden ở cả BP ON và BP OFF.
- BP ON IPC = **3.409**; BP OFF IPC = **1.901**.
- 6.056 nhánh điều kiện đã retire.
- 1.856 nhánh được giải quyết chính xác sớm ở Fetch.
- Predictor thực sự đưa ra dự đoán cho 4.200 nhánh: 3.091 đúng, 1.109 sai, accuracy **73.6%**, coverage **69.4%**.
- Loop Predictor và Perceptron không được chọn trong stress suite này. Mỗi random program được tạo một predictor mới và loop test chỉ chạy một trip, nên khó warm-up các predictor chuyên biệt.
- 1.109 lần redirect; 38.672 lệnh bị flush.

Không diễn giải 73.6% là accuracy mọi workload; đây là accuracy riêng của các quyết định predictor trên stress sample với cold-start.

## Workload lặp có quy luật

### Hai vòng lặp lồng nhau (100 vòng ngoài × 3 vòng trong)

- 400 nhánh điều kiện.
- 3 redirect.
- Predictor-only: **335/338 = 99.1%** trên số nhánh predictor thực sự dự đoán; các nhánh giải quyết sớm không nằm trong mẫu số này.
- Loop Predictor được chọn 30 lần.
- Perceptron được chọn 7 lần.
- Kết quả cuối cùng khớp golden.

### Loop-control kernel (2.000 vòng)

- Predictor-only: **1.999/2.000 = 99.95%**, coverage 100%.
- BP ON IPC = 5.589.
- 1 nhánh sai / 2.000 nhánh.

### Branch parity kernel (4.000 vòng, 8.000 nhánh điều kiện)

- Predictor-only: **7.995/8.000 = 99.94%**, coverage 100%.
- 5 nhánh sai / 8.000 nhánh.
- BP ON IPC = 5.990871.
- 294 lệnh bị flush.
- Trong workload này TAGE đã dự đoán rất tốt; Perceptron/Loop không cần được chọn.

## Đo thêm penalty phục hồi

Khi chạy `--alu 4 --penalty 1`:

- Stress IPC BP ON = **3.129**.
- Stress IPC BP OFF = 1.233.
- MIX IPC = 5.283.
- Branch parity kernel: 5/8.000 nhánh sai, predictor-only 99.94%.

Penalty 1 là giả định phục hồi bảo thủ hơn; không dùng con số này để so sánh với mặc định penalty 0.

## Kiểm thử an toàn bộ nhớ

Build với:

```bash
g++ -std=c++17 -O1 -g -Wall -Wextra -pedantic \
  -fsanitize=address,undefined -fno-omit-frame-pointer \
  HELIX1_BRANCH_V7.cpp -o helix1_v7_san
```

Chạy hết directed tests, random stress và IPC benchmarks với ASan/UBSan: **PASS**, không có báo cáo AddressSanitizer hoặc UndefinedBehaviorSanitizer.

## Kết luận

V7 giữ stress/MIX IPC gần V6 trong khi hạ integer ALU từ sáu xuống bốn. Nhánh-parity benchmark tăng mạnh nhờ sửa lỗi cập nhật BTB khi BEQ không được lấy. Tuy vậy, throughput thuần ALU bị giới hạn ở khoảng 4 IPC; đó là đánh đổi phần cứng thật, không phải vấn đề có thể khắc phục chỉ bằng predictor.
