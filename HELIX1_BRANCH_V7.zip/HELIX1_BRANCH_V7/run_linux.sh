#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -x ./helix1_v7 ]]; then
  g++ -std=c++17 -O2 -Wall -Wextra -pedantic HELIX1_BRANCH_V7.cpp -o helix1_v7
fi
exec ./helix1_v7 "$@"
