# HELIX-1 Branch V7

HELIX-1 Branch V7 là mô hình tham chiếu CPU OOO 64-bit viết bằng C++17, phát triển từ V6. Bản này giới hạn **4 cổng thực thi ALU số nguyên**, nhưng vẫn giữ frontend/dispatch tổng 6-wide.

## Cấu hình mặc định

| Thành phần | Cấu hình V7 |
|---|---:|
| Dispatch/execute tổng | 6 lệnh/chu kỳ |
| Integer ALU | **4 cổng** |
| Branch comparator | 1 khối riêng trong mô hình |
| Jump/target unit | Khối riêng trong mô hình |
| LSU address generation | Tách khỏi 4 integer ALU |
| LSU | 8 bank |
| Fetch | 12 lệnh/chu kỳ |
| Retire | 10 lệnh/chu kỳ |
| ROB | 128 entry |
| GHR / Path History | 128 bit / 128 bit |
| TAGE | 6 bảng lịch sử 4/8/16/32/64/128 |
| Perceptron | 32 bit lịch sử + bias, trọng số bão hòa |
| Loop Predictor | Trip count, main direction, confidence, speculative iteration và resync |
| Predictor selector | Bimodal/Gshare/Local/TAGE/Perceptron/Loop |
| Confidence Gating | Tắt mặc định (`--bp-confidence 0`) |

Bốn ALU được giới hạn ở các lệnh số học/logic thông thường (R-type và ADDI). Branch compare, jump, và tính địa chỉ LSU được mô hình như các khối riêng. Tổng số lệnh thực thi mỗi chu kỳ vẫn không vượt quá 6.

## Điểm nâng cấp V7

1. **4 integer ALU:** bộ lập lịch chỉ chọn tối đa bốn lệnh ALU số nguyên trong một chu kỳ; vẫn có thể issue cùng chu kỳ với branch/jump và memory nếu còn slot dispatch.
2. **TAGE + Perceptron:** Perceptron 32-bit được huấn luyện theo global history và chỉ thắng quyền chọn khi đã đủ mẫu, điểm usefulness tốt hơn TAGE và biên dự đoán đủ lớn.
3. **Loop Predictor:** học hướng lặp chính, trip count và confidence. Khi predictor mới đủ tin cậy giữa lúc frontend đã đi sâu vào loop, cơ chế resync chờ đến ranh giới vòng tiếp theo trước khi override TAGE.
4. **Adaptive allocator:** nếu chưa có TAGE provider, cấp phát sau miss đầu tiên; nếu provider hiện có dự đoán sai, yêu cầu hai miss trước khi cấp phát tầng dài hơn.
5. **BTB correction:** BEQ không được lấy không ghi fall-through vào BTB. Chỉ cập nhật target của BEQ khi nhánh thực sự được lấy. Điều này tránh dự đoán đúng hướng nhưng sai target do BTB bị ghi đè bằng địa chỉ tuần tự.
6. **Rollback:** loop speculative iteration được checkpoint và phục hồi cùng local history/GHR/path/RAS khi squash.

## Build và chạy Linux

Yêu cầu `g++` hỗ trợ C++17.

```bash
chmod +x run_linux.sh
./run_linux.sh
```

Hoặc build thủ công:

```bash
g++ -std=c++17 -O2 -Wall -Wextra -pedantic \
  HELIX1_BRANCH_V7.cpp -o helix1_v7
./helix1_v7
```

Một số tùy chọn:

```bash
./helix1_v7 --alu 4 --bp-confidence 0
./helix1_v7 --alu 4 --penalty 1
./helix1_v7 --alu 4 --entries 1024 --hist-bits 128
```

`--alu` nhận 1..4. Mặc định là 4. `--penalty 0` giả lập redirect trong cùng chu kỳ; `--penalty 1` thêm một chu kỳ phục hồi. `--bp-confidence 0` không stall Fetch vì độ tự tin thấp.

## Kiểm thử đã chạy

- 25 bài kiểm thử định hướng: PASS.
- 1.000 chương trình ngẫu nhiên (500 chương trình có vòng lặp), seed 2026: khớp mô hình golden 100% ở cả predictor ON/OFF.
- 353 chương trình fault được so sánh theo semantics fault của golden.
- AddressSanitizer + UndefinedBehaviorSanitizer: PASS.

Số liệu chi tiết nằm trong `BENCHMARKS.md`, `test_results_final.txt`, `test_results_penalty1.txt` và `sanitizer_results.txt`.

## Giới hạn quan trọng

Đây là **mô hình mô phỏng C++17**, không phải SystemVerilog RTL, không chứng minh timing/tần số FPGA, điện năng hay nhiệt độ. Khả năng đồng thời của branch comparator, jump và LSU address generation là giả định kiến trúc trong mô hình cần được ánh xạ thành cổng RTL riêng nếu triển khai phần cứng.
